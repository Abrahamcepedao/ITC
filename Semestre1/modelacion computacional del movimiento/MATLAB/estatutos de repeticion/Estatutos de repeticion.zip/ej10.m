%Ana Sofía fernandes
%Sabina Avila
%Alexa Gonzalez
num = input("Teclea un número: ");
for i = 0:20
    fprintf("%i * %i = %i \n", num, i, (num*i))
end