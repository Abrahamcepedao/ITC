%Ana Sofía fernandes
%Sabina Avila
%Alexa Gonzalez
for h = 0:23
    for m = 0:59
        for s = 0:59
            fprintf("%i:%i:%i\n",h,m,s)
        end
    end
end