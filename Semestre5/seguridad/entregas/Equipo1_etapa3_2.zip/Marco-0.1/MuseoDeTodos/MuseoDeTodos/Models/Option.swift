//
//  Option.swift
//  MuseoDeTodos
//
//  Created by Abraham Cepeda Oseguera on 24/08/21.
//

import Foundation


struct Option {
    let title: String
    let image: String
}
