export const NAME = "NAME";
export const F_LASTNAME = "F_LASTNAME";
export const M_LASTNAME = "M_LASTNAME";
export const EMAIL = "EMAIL";
export const DATE = "DATE";