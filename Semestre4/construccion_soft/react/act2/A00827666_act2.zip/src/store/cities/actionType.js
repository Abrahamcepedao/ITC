export const SELECT_CITY = "SELECT_CITY"
export const DELETE_CITY = "DELETE_CITY"