import './App.css';
import React from 'react';
import Home from './pages/Home';

function App() {
  return (
    <div className="App" style={{paddding: '20px'}}>
      <Home/>
    </div>
  );
}

export default App;
