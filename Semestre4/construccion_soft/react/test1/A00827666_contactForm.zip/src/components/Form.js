import React from 'react';
import BaseField from './BaseField';

class Form extends BaseField{
    constructor(props){
        super(props);
    }
    render(){
        return (
            <div {...this.props}>
                
            </div>
            
        )
    }

}

export default Form;
