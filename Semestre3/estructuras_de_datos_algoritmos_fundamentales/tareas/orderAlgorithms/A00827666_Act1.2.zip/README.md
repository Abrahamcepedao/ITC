# Act 1.2 Order & Search algorithms - Abraham Cepeda Oseguera - A00827666
This activity consists of several algorithms that implements order and search algorithms

## Complexity of each algorithm
* Exchange   - O(n^2)
* Bubble     - O(n^2)
* Selection  - O(n^2)
* Insertion  - O(n^2)
* Merge      - O(nlogn)
* Quick      - O(nlogn)
* Sequential - O(n)
* Binary     - O(logn)