# Act 1.0 Templates - Abraham Cepeda Oseguera - A00827666
This activity consists of a program that manipulates an array that   can have several datatypes since the class uses Templates.
The class "ListaT.h" is the one that uses templates. Therefore, the main file includes this class.

## Activity requirements
The class must have the following capabilities (methods):
* Insert element 
* Erase last element
* Get element
* Get size of array
* Print entire array

## Complexity of each function
* Insert element       - O(1)
* Erase last element   - O(1)
* Get element          - O(1)
* Get size of array    - O(1)
* Print entire array   - O(N)