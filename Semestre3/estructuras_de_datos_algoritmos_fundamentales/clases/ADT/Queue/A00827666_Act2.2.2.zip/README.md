# Act 2.2.2 - Implementación de un ADT de estructura de datos lineales - Queue


## **Functions**
* getSize    -  O(1)
* enqueue    -  O(1)
* dequeue    -  O(1)
* front      -  O(1)
* back       -  O(1)
* clear      -  O(n)
* print      -  O(n)